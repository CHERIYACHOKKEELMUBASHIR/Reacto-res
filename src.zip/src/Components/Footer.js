import React from 'react'
import '../Components/Foot.css'

function Footer() {
  return (
    <div className='foot'><h1>THIS IS FOOTER</h1></div>
  )
}

export default Footer